from flask import Flask, render_template, request, redirect, url_for, session, flash
from functools import wraps

app = Flask(__name__)
app.secret_key = 'local-demo-only-change-this-before-deployment'

TOKENS = [
    dict(name='HUNKIT', symbol='HUNK', chain='SOL', age='31m', price='$0.00482', change='+15.77%', mcap='$440K', volume='$2.02M', liquidity='$86.4K', holders='1,140', tx='12.93K', top10='18.4%', dev='2.1%', risk='Medium', color='violet', score=78),
    dict(name='Darla', symbol='DARLA', chain='SOL', age='12m', price='$0.00091', change='+656.3%', mcap='$23.77K', volume='$134.39K', liquidity='$18.2K', holders='280', tx='3.47K', top10='22.8%', dev='4.8%', risk='High', color='pink', score=54),
    dict(name='fair', symbol='FAIR', chain='SOL', age='19m', price='$0.00134', change='+405.6%', mcap='$13.79K', volume='$153.33K', liquidity='$21.6K', holders='209', tx='3.25K', top10='15.1%', dev='0.0%', risk='Medium', color='mint', score=72),
    dict(name='Ducky', symbol='DUCKY', chain='SOL', age='22m', price='$0.00072', change='+264.9%', mcap='$10.97K', volume='$72.05K', liquidity='$12.8K', holders='287', tx='2.24K', top10='27.2%', dev='3.3%', risk='High', color='yellow', score=61),
    dict(name='Pilly', symbol='PILLY', chain='SOL', age='43m', price='$0.00208', change='+144.7%', mcap='$8.28K', volume='$135.36K', liquidity='$31.1K', holders='158', tx='3.28K', top10='19.7%', dev='1.4%', risk='Low', color='blue', score=84),
    dict(name='PEPE', symbol='PEPE', chain='ETH', age='17m', price='$0.0000067', change='+245.3%', mcap='$11.91K', volume='$81.73K', liquidity='$16.4K', holders='149', tx='1.46K', top10='31.6%', dev='5.1%', risk='High', color='green', score=49),
    dict(name='Robert', symbol='ROBERT', chain='BASE', age='6m', price='$0.00018', change='+98.2%', mcap='$7.34K', volume='$81.67K', liquidity='$9.7K', holders='98', tx='940', top10='24.2%', dev='0.9%', risk='Medium', color='orange', score=67),
    dict(name='MoonPup', symbol='MPUP', chain='BSC', age='1h', price='$0.00031', change='-8.4%', mcap='$68.2K', volume='$45.2K', liquidity='$14.9K', holders='612', tx='1.02K', top10='38.2%', dev='8.0%', risk='High', color='purple', score=38),
]
WALLETS = [
    dict(label='Smart Money #01', address='7xQm...4kDp', win='78.4%', pnl='+$42,810', trades='324', roi='+184%'),
    dict(label='Early Bird', address='9Fga...Ls2v', win='69.2%', pnl='+$18,420', trades='186', roi='+126%'),
    dict(label='Solana Scout', address='Bn4t...Rq7c', win='64.8%', pnl='+$9,760', trades='241', roi='+82%'),
]

@app.context_processor
def inject_globals():
    return {'demo_mode': True, 'current_user': session.get('user_name', 'Guest trader'), 'is_guest': not session.get('signed_in', False)}

def page(template, title, **kwargs):
    return render_template(template, title=title, tokens=TOKENS, **kwargs)

@app.route('/')
def index(): return redirect(url_for('dashboard'))
@app.route('/dashboard')
def dashboard(): return page('dashboard.html', 'Overview', active='dashboard', movers=TOKENS[:5], wallets=WALLETS)
@app.route('/discover')
def discover(): return page('discover.html', 'Discover', active='discover')
@app.route('/trenches')
def trenches(): return page('trenches.html', 'Trenches', active='trenches')
@app.route('/token/<symbol>')
def token_detail(symbol):
    token = next((t for t in TOKENS if t['symbol'].lower() == symbol.lower() or t['name'].lower() == symbol.lower()), TOKENS[0])
    return page('token.html', token['name'], active='discover', token=token)
@app.route('/portfolio')
def portfolio(): return page('portfolio.html', 'Portfolio', active='portfolio')
@app.route('/watchlist')
def watchlist(): return page('watchlist.html', 'Watchlist', active='watchlist')
@app.route('/wallets')
def wallets(): return page('wallets.html', 'Wallet tracker', active='wallets', wallets=WALLETS)
@app.route('/copy-trading')
def copy_trading(): return page('copy.html', 'Copy trading', active='copy', wallets=WALLETS)
@app.route('/alerts')
def alerts(): return page('alerts.html', 'Alerts', active='alerts')
@app.route('/settings')
def settings(): return page('settings.html', 'Settings', active='settings')
@app.route('/auth')
def auth(): return page('auth.html', 'Sign in')
@app.route('/guest')
def guest():
    session.clear(); return redirect(url_for('dashboard'))
@app.route('/demo-google-signin', methods=['POST'])
def demo_google_signin():
    # Deliberately a visual-only placeholder. It does not authenticate with Google.
    session['signed_in'] = True
    session['user_name'] = 'Demo account'
    flash('Demo sign-in only — Google OAuth is not connected yet.', 'info')
    return redirect(url_for('dashboard'))
@app.route('/signout')
def signout():
    session.clear(); return redirect(url_for('auth'))
@app.route('/demo-action', methods=['POST'])
def demo_action():
    action = request.form.get('action', 'Action')
    flash(f'{action} is a prototype interaction. No order or blockchain transaction was sent.', 'info')
    return redirect(request.referrer or url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
