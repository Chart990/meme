(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const storedTheme = localStorage.getItem('memescope-theme');
  if (storedTheme === 'light') document.body.classList.add('light-theme');
  window.toggleTheme = () => { document.body.classList.toggle('light-theme'); localStorage.setItem('memescope-theme', document.body.classList.contains('light-theme') ? 'light' : 'dark'); };
  $$('.theme-toggle').forEach(b => b.addEventListener('click', window.toggleTheme));
  window.showToast = (message) => { let toast = $('.local-toast'); if (!toast) { toast=document.createElement('div'); toast.className='toast local-toast'; document.body.appendChild(toast); } toast.textContent=message; toast.classList.add('visible'); clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>toast.classList.remove('visible'),3200); };
  window.copyText = async (text) => { try { await navigator.clipboard.writeText(text); showToast('Copied demo value.'); } catch(e) { showToast('Demo value: '+text); } };
  const search = $('#tokenSearch');
  const applyFilters = () => {
    const q=(search?.value||$('#tableSearch')?.value||'').toLowerCase(); const risk=$('#riskFilter')?.value||'ALL'; const chain=$('.chain-tabs button.active')?.dataset.chain||'ALL';
    let rows=$$('.filterable-table tbody tr'); rows.forEach(row=>{const matchQ=(row.dataset.name||row.innerText.toLowerCase()).includes(q); const matchRisk=risk==='ALL'||row.dataset.risk===risk; const matchChain=chain==='ALL'||row.dataset.chain===chain; row.hidden=!(matchQ&&matchRisk&&matchChain);});
    const count=rows.filter(r=>!r.hidden).length; if($('#resultCount')) $('#resultCount').textContent=`${count} sample asset${count===1?'':'s'}`;
  };
  if(search) search.addEventListener('input',applyFilters); if($('#riskFilter')) $('#riskFilter').addEventListener('change',applyFilters);
  if($('#tableSearch')) $('#tableSearch').addEventListener('input', e=>{const q=e.target.value.toLowerCase(); $$('.data-table tbody tr').forEach(r=>r.hidden=!r.innerText.toLowerCase().includes(q));});
  $$('.chain-tabs button').forEach(b=>b.addEventListener('click',()=>{ $$('.chain-tabs button').forEach(x=>x.classList.remove('active')); b.classList.add('active'); const chain=b.dataset.chain; if(search) applyFilters(); else $$('.token-card').forEach(c=>c.hidden=!(chain==='ALL'||c.dataset.chain===chain)); }));
  window.resetFilters=()=>{if(search)search.value='';if($('#riskFilter'))$('#riskFilter').value='ALL';$$('.chain-tabs button').forEach((b,i)=>b.classList.toggle('active',i===0));applyFilters();};
  $$('[data-amount]').forEach(b=>b.addEventListener('click',()=>{const input=$('input[name="amount"]');if(input)input.value=b.dataset.amount;}));
  $$('[data-trade-tab]').forEach(b=>b.addEventListener('click',()=>{ $$('[data-trade-tab]').forEach(x=>x.classList.toggle('active',x===b)); const sell=b.dataset.tradeTab==='sell'; if($('#tradeSubmit')){ $('#tradeSubmit').textContent=sell?'Preview demo sell ↗':'Preview demo buy ↗'; $('#tradeAction').value=sell?'Demo sell':'Demo buy'; $('#tradeSubmit').classList.toggle('sell-button',sell); } }));
  $$('[data-auth-tab]').forEach(b=>b.addEventListener('click',()=>{ $$('[data-auth-tab]').forEach(x=>x.classList.toggle('active',x===b)); const signup=b.dataset.authTab==='signup'; if($('#authTitle'))$('#authTitle').textContent=signup?'Create your workspace':'Welcome back'; if($('#authSub'))$('#authSub').textContent=signup?'Start with a private workspace in a few seconds.':'Sign in to continue to your workspace.'; if($('#googleLabel'))$('#googleLabel').textContent=signup?'Sign up with Google':'Continue with Google'; }));
  $$('.segmented button').forEach(b=>b.addEventListener('click',()=>{const parent=b.parentElement;$$('button',parent).forEach(x=>x.classList.toggle('active',x===b)); if(b.dataset.range) showToast(`Chart range set to ${b.dataset.range} (illustrative chart).`);}));
  $$('.switch').forEach(b=>b.addEventListener('click',()=>{b.classList.toggle('active');showToast('Preference toggled in this prototype.');}));
  $$('.remove-row').forEach(b=>b.addEventListener('click',()=>{b.closest('tr').remove();showToast('Removed sample row from this view.');}));
})();
