# MemeScope — private meme-coin terminal prototype

A responsive Flask + HTML + CSS + vanilla JavaScript UI prototype inspired by the general workflow shown in your GMGN screenshots. It uses **fictional, static demo data only**. There is no market-data API, Google OAuth, wallet connection, backend database, or blockchain transaction functionality yet.

## Features included
- Responsive desktop sidebar and mobile bottom navigation
- Overview dashboard with portfolio, activity, market snapshot and demo charts
- Discover and Trenches token tables with chain/timeframe filters and search
- Token detail page with chart placeholder, token metrics, holder/risk panels and mock buy/sell controls
- Portfolio, watchlist, wallet tracker, copy-trading, alerts and settings pages
- Sign-in/sign-up landing page with a Google-style demo button and guest access
- Dark/light theme toggle, table search, toast notices, mobile navigation
- All trade/order buttons are explicitly demo-only and never submit transactions

## Run locally
Python 3.10+ recommended.

```bash
cd meme_terminal
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 in your browser.

## Android / Termux
```bash
pkg update
pkg install python
cd ~/meme_terminal
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000` in your phone browser. To access it from another device on the same Wi-Fi, change `host='127.0.0.1'` to `host='0.0.0.0'` and use the computer's local IP. Do not expose the development server to the public internet.

## Before real authentication or trading
- Implement Google OAuth with a proper provider flow; the current button is only a UI demo.
- Add CSRF protection, secure session settings, input validation, tests and a persistent database.
- Use reputable read-only market data sources first, with caching and rate limits.
- For any future trading integration, use a wallet provider and explicit transaction signing. Never collect seed phrases or private keys.
- Add risk disclosures and token-contract / liquidity / holder concentration checks. Static risk labels here are invented sample values.
